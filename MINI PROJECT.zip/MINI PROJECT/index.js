window.addEventListener("scroll", function(){
    var header = document.querySelector("header");
    header.classList.toggle('sticky', window.scrollY > 0)
});

var menu = document.querySelector('.navi');
var hamBtn = document.querySelector('.hamBtn');
var closeBtn = document.querySelector('.closeBtn');
hamBtn.addEventListener("click", () =>{
    menu.classList.add('active');
});

closeBtn.addEventListener("click", () => {
    menu.classList.remove('active');
})

function validateName() {
    let inputName = document.querySelector("#nameFirst");
    let inputNamee = document.querySelector("#nameLast");
    let valueName = inputName.value;
    let errorName = document.querySelector("#error-name");
  
    if (valueName == "") {
      errorName.innerHTML = "Name cannot be empty!";
      inputName.style.border = "1px solid red";
      inputNamee.style.border = "1px solid red";
      return false;
    } else {
      errorName.innerHTML = "";
      inputName.style.border = "1px solid black";
      inputNamee.style.border = "1px solid black";
      return true;
    }
  }
  
  function validateEmail() {
    let inputEmail = document.querySelector("#email");
    let valueEmail = inputEmail.value;
    let errorEmail = document.querySelector("#error-email");
  
    if (valueEmail == "") {
      errorEmail.innerHTML = "Email cannot be empty!";
      inputEmail.style.border = "1px solid red";
      return false;
    } else if (!valueEmail.includes("@")) {
      errorEmail.innerHTML = "Email must contain '@'!";
      inputEmail.style.border = "1px solid red";
      return false;
    } else {
      errorEmail.innerHTML = "";
      inputEmail.style.border = "1px solid black";
      return true;
    }
  }
  
  function validateNumber() {
    let inputNumber = document.querySelector("#number");
    let valueNumber = inputNumber.value;
    let errorNumber = document.querySelector("#error-number");
  
    if (valueNumber === "") {
      errorNumber.innerHTML = "Number cannot be empty!";
      inputNumber.style.border = "1px solid red";
      return false;
    } else if (isNaN(valueNumber)) {
      errorNumber.innerHTML = "Please enter a valid number!";
      inputNumber.style.border = "1px solid red";
      return false;
    } else {
      errorNumber.innerHTML = "";
      inputNumber.style.border = "1px solid black";
      return true;
    }
}

function validateMessage() {
    let inputMessage = document.querySelector("#message");
    let valueMessage = inputMessage.value;
    let errorMessage = document.querySelector("#error-message");
  
    if (valueMessage == "") {
      errorMessage.innerHTML = "Message cannot be empty!";
      inputMessage.style.border = "1px solid red";
      return false;
    } else {
      errorMessage.innerHTML = "";
      inputMessage.style.border = "1px solid black";
      return true;
    }
  }
  
  let sendBtn = document.querySelector("#send-btn");
  sendBtn.addEventListener("click", function (e) {
    e.preventDefault(); // Stop form submission
  
    let isNameValid = validateName();
    let isEmailValid = validateEmail();
    let isNumberValid = validateNumber();
    let isMessageValid = validateMessage();
  
    if (
      isNameValid &&
      isEmailValid &&
      isNumberValid &&
      isMessageValid
    ) {
      let sendForm = document.querySelector("#contactUs");
      alert("FORM SUBMITTED!");
      sendForm.submit(); // SUBMIT FORM
    }
  });
  